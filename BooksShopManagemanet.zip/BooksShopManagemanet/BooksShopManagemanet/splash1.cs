﻿using System.Windows.Forms;

namespace BooksShopManagemanet
{
    internal class splash : Form
    {
    }
}